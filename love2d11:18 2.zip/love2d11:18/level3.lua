-- level3.lua

return {
    chickens = {}, -- Chickens carry over from previous levels
    initialMoney = 800,
    dayDuration = 40,
    nightDuration = 20,
    requiredCustomers = 999, -- Endless level
    predatorsActive = true
}
