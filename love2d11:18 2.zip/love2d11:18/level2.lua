-- level2.lua

return {
    chickens = {}, -- Chickens carry over from Level 1
    initialMoney = 800,
    dayDuration = 40,
    nightDuration = 15,
    requiredCustomers = 2,
    predatorsActive = false
}
