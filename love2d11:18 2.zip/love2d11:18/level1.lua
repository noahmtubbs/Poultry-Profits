-- level1.lua

return {
    chickens = {
        {x = 600, y = 350},
        {x = 600, y = 400},
        {x = 400, y = 350},
        {x = 400, y = 400}
    },
    initialMoney = 900,
    dayDuration = 40,
    nightDuration = 10,
    requiredCustomers = 1,
    predatorsActive = true
}
