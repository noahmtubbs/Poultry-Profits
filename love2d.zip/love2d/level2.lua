-- level2.lua

return {
    chickens = {}, -- Chickens carry over from Level 1
    initialMoney = 0,
    dayDuration = 40,
    nightDuration = 15,
    requiredCustomers = 10,
    predatorsActive = false
}
